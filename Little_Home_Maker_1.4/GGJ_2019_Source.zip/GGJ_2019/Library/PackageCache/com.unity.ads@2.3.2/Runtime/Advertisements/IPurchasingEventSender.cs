internal interface IPurchasingEventSender
{
    void SendPurchasingEvent(string payload);
}
